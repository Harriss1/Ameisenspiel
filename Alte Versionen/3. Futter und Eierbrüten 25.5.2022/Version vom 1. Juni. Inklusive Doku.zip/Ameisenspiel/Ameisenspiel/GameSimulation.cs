﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// Not used right now. Maybe usefull if the project becomes huge.
/// GameSimulation implements one instance of the World
/// The World implements Entities (Entity.makeAnt)
/// Entities implement Ants or The Nest or Obstacles
/// Ants implement Carriage

namespace Ameisenspiel {
    internal class GameSimulation {
    }
}
