﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ameisenspiel {
    internal class Test {
        int x;
        public Test() : this(1){
            
        }

        public Test(int x) {
            this.x = x;
        }
    }
}
